const DEVICE_ORIENTATION_TYPE = Object.freeze({
    UNKNOWN: 0,
    PORTRAIT: 1,
    PORTRAIT_UPSIDE_DOWN: 2,
    LANDSCAPE_LEFT: 3,
    LANDSCAPE_RIGHT: 4,
    FACE_UP: 5,
    FACE_DOWN: 6
})

const INTERFACE_ORIENTATION_TYPE = Object.freeze({
    UNKNOWN: 0,
    PORTRAIT: 1,
    PORTRAIT_UPSIDE_DOWN: 2,
    LANDSCAPE_LEFT: 3,
    LANDSCAPE_RIGHT: 4
})

const KEY_TYPE = Object.freeze({
    HOME_BUTTON: 0x40,
    VOLUME_DOWN_BUTTON: 0xEA,
    VOLUME_UP_BUTTON: 0xE9,
    POWER_BUTTON: 0x30
})

const CONTROLLER_TYPE = Object.freeze({
    LABEL: 1,
    INPUT: 2,
    PICKER: 3,
    SWITCH: 4,
    BUTTON: 5,
    REMEMBER: 6
})

const OCR_METHOD = Object.freeze({
    IOS_VISION: 1,
    AI_CLOUD: 2,
})

//--------------------------------------
// function setInterval(func, interval) {
// 	return _at.setInterval(func, interval)
// }

// function clearInterval(timerId) {
// 	_at.clearInterval(timerId)
// }
//-------------------------------------

const at = {}

at.touchDown = function () {
    _at.touchDown(...arguments)
}

at.touchMove = function () {
    _at.touchMove(...arguments)
}

at.touchUp = function () {
    _at.touchUp(...arguments)
}

at.keyDown = function () {
    _at.keyDown(...arguments)
}

at.keyUp = function () {
    _at.keyUp(...arguments)
}

at.keyPress = function (keyType) {
    at.keyDown(keyType);
    _usleep(10000);
    at.keyUp(keyType);
}

at.tap = function (x, y) {
    _at.touchDown(0, x, y)
    _usleep(16000)
    _at.touchUp(0, x, y)
}

at.inputText = function () {
    _at.inputText(...arguments)
}

at.usleep = function () {
    _usleep(...arguments)
}

usleep = function () {
    _usleep(...arguments)
}

// toast({message, delay})
at.toast = function () {
    // let str = utils.format(...arguments);
    let message, position = 1, delay = 2
    if (arguments.length == 0) {
        throw Error("Usage of toast should be toast(message, 'top|center|bottom', delaySeconds)")
    }
    message = arguments[0]
    if (typeof arguments[1] === 'string') {
        switch (arguments[1]) {
            case 'top':
                position = 1;
                break;
            case 'center':
                position = 2;
                break;
            case 'bottom':
                position = 3;
                break;
            default:
                throw Error("Toast position must be string 'top', 'center' or 'bottom'")
        }

        if (typeof arguments[2] === 'number') {
            delay = arguments[2]
        }
    } else if (typeof arguments[1] === 'number') {
        delay = arguments[1]
    }

    _at.toast(message, position, delay)
}

at.vibrate = function () {
    _at.vibrate()
}

at.rootDir = function () {
    return _at.rootDir()
}

at.getSN = function () {
    return _at.getSN()
}

at.getVersion = function () {
    return _at.getVersion()
}

at.getScreenInfo = function () {
    return _at.getScreenInfo()
}

at.getDeviceOrientation = function () {
    return _at.getDeviceOrientation()
}

at.frontMostAppOrientation = function () {
    return _at.frontMostAppOrientation()
}

at.frontMostAppId = function () {
    return _at.frontMostAppId()
}

at.appState = function (appIdentifier) {
    return _at.appState(appIdentifier);
}

at.appIsActive = function (appIdentifier) {
    if (appIdentifier == "com.apple.SpringBoard") {
        return _at.frontMostAppId() == null;
    }
    return "ACTIVATED" == _at.appState(appIdentifier);
}

at.appRun = function (appIdentifier) {
    if (appIdentifier == "com.apple.SpringBoard") {
        at.keyPress(KEY_TYPE.HOME_BUTTON);
    } else {
        _at.appDoRun(appIdentifier);
    }
}

at.appActivate = function (appIdentifier) {
    let firstLoop = true
    while (!at.appIsActive(appIdentifier)) {
        if (!firstLoop) {
            _usleep(500000)
        } else {
            firstLoop = false
        }
        at.appRun(appIdentifier);
    }
}

at.appKill = function (appIdentifier) {
    _at.appKill(appIdentifier)
}

at.appInfo = function (appIdentifier) {
    return _at.appInfo(appIdentifier)
}
//---------------------------------------

at.screenshot = function (savePath, region, scale, quality) {
    // Can not be like this: { savepath, region }
    return _at.screenshot({ savePath: savePath, region: region, scale: scale, quality: quality })
}

at.getColor = function (x, y) {
    // Can not be like this: { x, y }
    return _at.getColors({ locations: [{ x: x, y: y }] })
}

at.getColors = function (locations) {
    // Can not be like this: { locations }
    return _at.getColors({ locations: locations })
}

at.dumpColorsOfScreen = function (savePath, region, rgb, coordinates) {
    // Can not be like this: { savePath, region }
    return _at.dumpColorsOfScreen({ savePath: savePath, region: region, rgb: rgb, coordinates: coordinates })
}

at.dumpColorsOfImage = function (imagePath, savePath, region, rgb, coordinates) {
    // Can not be like this: { imagePath, savePath, region }
    return _at.dumpColorsOfImage({ imagePath: imagePath, savePath: savePath, region: region, rgb: rgb, coordinates: coordinates })
}

at.drawDebugImage = function (imagePath, savePath, points, regions, color, lineWidth) {
    // Can not be like this: { imagePath, savePath, region }
    return _at.drawDebugImage({ imagePath: imagePath, savePath: savePath, points: points, regions: regions, color: color, lineWidth: lineWidth })
}

at.findColor = function (params) {
    const args = params
    args.colors = [{ color: params.color, x: 0, y: 0 }]
    delete args.color
    return at.findColors(args)
}

at.findColorAsync = function (args, callback) {
    dispatch_async_global_queue(function () {
        const result = findColor(args)
        if (callback) {
            callback(...result)
        }
    })
}

at.findColors = function () {
    const isOneTimeExecutionSync = arguments.length === 1 && arguments[0].hasOwnProperty('colors') && Array.isArray(arguments[0].colors);
    const isOneTimeExecutionAsync = arguments.length === 2 && arguments[0].hasOwnProperty('colors') && Array.isArray(arguments[0].colors) && (typeof arguments[1] === 'function');
    if (isOneTimeExecutionSync) {
        const options = arguments[0]
        // Default count is 10
        if (options.count) {
            options.count = 10
        }
        return _at.findColors(options)
    } else if (isOneTimeExecutionAsync) {
        dispatch_async_global_queue(() => {
            const options = arguments[0]
            // Default count is 10
            if (options.count) {
                options.count = 10
            }
            const result = _at.findColors(options)
            const callback = arguments[1]
            callback(...result)
        })
        return
    }

    const { options, duration, interval, eachFindingCallback, foundCallback, exitIfFound, errorCallback, completedCallback, block } = arguments[0]

    // Default count is 10
    if (!options.count) {
        options.count = 10
    }

    const handleError = errorMessage => {
        if (errorCallback) {
            errorCallback(errorMessage)
        } else {
            alert(`Got error while finding colors and you didn't provide the errorCallback parameter! Error: ${errorMessage}`)
        }
    }

    if (exitIfFound === null || exitIfFound === undefined) {
        exitIfFound = true
    }

    if (block === null || block === undefined) {
        block = false
    }

    const interval_ = interval && interval > 0 ? interval : 1000

    const isValidDate = function (date) {
        return (new Date(date) !== "Invalid Date") && !isNaN(new Date(date));
    }

    let findingTimes, findingTimeLong, findingTillTime
    if (!duration) {
        findingTimes = 10
    } else {
        let durationType
        if (typeof duration === 'number') {
            durationType = 'findingTimes'
        } else if (typeof duration === 'string') {
            if (duration.match(/\d[sS]{1}/g)) {
                durationType = 'findingTimeLong'
            } else if (isValidDate(duration)) {
                durationType = 'findingTillTime'
            } else {
                handleError(`Invalid parameter duration: ${duration}`)
                return
            }
        } else {
            handleError(`Invalid parameter duration: ${duration}`)
            return
        }

        if (durationType === 'findingTimes') {
            if (duration > 0) {
                findingTimes = duration
            } else {
                handleError(`Invalid parameter duration: ${duration}`)
                return
            }
        } else if (durationType === 'findingTimeLong') {
            let t = parseInt(duration.slice(0, -1))
            if (t > 0) {
                findingTimeLong = t * 1000 // seconds to milliseconds
            } else {
                handleError(`Invalid parameter duration: ${duration}`)
                return
            }
        } else if (durationType === 'findingTillTime') {
            try {
                const tillTime = new Date(duration)
                if (tillTime > new Date()) {
                    findingTillTime = tillTime
                } else {
                    handleError(`Invalid parameter duration: ${duration}`)
                    return
                }
            } catch (error) {
                handleError(`Invalid parameter duration: ${duration}, error: ${error}`)
                return
            }
        } else {
            handleError(`You have to provide a format valid duration!`)
            return
        }
    }

    const doFinding = () => {
        return new Promise((resolve, reject) => {
            const [result, error] = _at.findColors(options)
            // If got error, or got result, then the task is done
            if (error) {
                reject(error)
            } else {
                resolve(result)
            }
        })
    }

    const oneLoop = async () => {
        let result
        try {
            result = await doFinding()
        } catch (error) {
            handleError(error)
            return true // exit findColors()
        }
        if (eachFindingCallback) {
            eachFindingCallback()
        }
        if (result && result.length > 0) {
            const found = result && result.length > 0;
            if (found) {
                if (foundCallback) {
                    foundCallback(result)
                }
                if (exitIfFound) {
                    return true // exit findColors()
                }
            }
        }
        return false // do not exit findColors()
    }

    const doLoops = async () => {
        if (findingTimes) {
            let i = 1
            let firstLoop = true
            while (i < findingTimes) {
                if (!firstLoop) {
                    _usleep(interval_ * 1000)
                } else {
                    firstLoop = false
                }
                const exit = await oneLoop()
                if (exit) {
                    if (completedCallback) {
                        completedCallback()
                    }
                    return // exit findColors()
                }
                i++
            }
            if (completedCallback) {
                completedCallback()
            }
        } else if (findingTimeLong) {
            const startTime = new Date()
            let firstLoop = true
            while ((new Date() - startTime) < findingTimeLong) {
                if (!firstLoop) {
                    _usleep(interval_ * 1000)
                } else {
                    firstLoop = false
                }
                const exit = await oneLoop()
                if (exit) {
                    if (completedCallback) {
                        completedCallback()
                    }
                    return // exit findColors()
                }
            }
            if (completedCallback) {
                completedCallback()
            }
        } else if (findingTillTime) {
            let firstLoop = true
            while (new Date() < findingTillTime) {
                if (!firstLoop) {
                    _usleep(interval_ * 1000)
                } else {
                    firstLoop = false
                }
                const exit = await oneLoop()
                if (exit) {
                    if (completedCallback) {
                        completedCallback()
                    }
                    return // exit findColors()
                }
            }
            if (completedCallback) {
                completedCallback()
            }
        }
    }

    if (block) {
        return doLoops()
    } else {
        dispatch_async_global_queue(() => {
            return doLoops()
        })
    }
}

at.findImage = function () {
    const isOneTimeExecutionSync = arguments.length === 1 && arguments[0].hasOwnProperty('targetImagePath') && (typeof arguments[0].targetImagePath === 'string');
    const isOneTimeExecutionAsync = arguments.length === 2 && arguments[0].hasOwnProperty('targetImagePath') && (typeof arguments[0].targetImagePath === 'string') && (typeof arguments[1] === 'function');
    if (isOneTimeExecutionSync) {
        const options = arguments[0]
        // Default count is 10
        if (options.count) {
            options.count = 10
        }
        return _at.findImage(options)
    } else if (isOneTimeExecutionAsync) {
        dispatch_async_global_queue(() => {
            const options = arguments[0]
            // Default count is 10
            if (options.count) {
                options.count = 10
            }
            const result = _at.findImage(options)
            const callback = arguments[1]
            callback(...result)
        })
        return
    }

    const { options, duration, interval, eachFindingCallback, foundCallback, exitIfFound, errorCallback, completedCallback, block } = arguments[0]

    // Default count is 10
    if (!options.count) {
        options.count = 10
    }

    const handleError = errorMessage => {
        if (errorCallback) {
            errorCallback(errorMessage)
        } else {
            alert(`Got error while findImage and you didn't provide the errorCallback parameter! Error: ${errorMessage}`)
        }
    }

    if (exitIfFound === null || exitIfFound === undefined) {
        exitIfFound = true
    }

    if (block === null || block === undefined) {
        block = false
    }

    const interval_ = interval && interval > 0 ? interval : 1000

    const isValidDate = function (date) {
        return (new Date(date) !== "Invalid Date") && !isNaN(new Date(date));
    }

    let findingTimes, findingTimeLong, findingTillTime
    if (!duration) {
        findingTimes = 10
    } else {
        let durationType
        if (typeof duration === 'number') {
            durationType = 'findingTimes'
        } else if (typeof duration === 'string') {
            if (duration.match(/\d[sS]{1}/g)) {
                durationType = 'findingTimeLong'
            } else if (isValidDate(duration)) {
                durationType = 'findingTillTime'
            } else {
                handleError(`Invalid parameter duration: ${duration}`)
                return
            }
        } else {
            handleError(`Invalid parameter duration: ${duration}`)
            return
        }

        if (durationType === 'findingTimes') {
            if (duration > 0) {
                findingTimes = duration
            } else {
                handleError(`Invalid parameter duration: ${duration}`)
                return
            }
        } else if (durationType === 'findingTimeLong') {
            let t = parseInt(duration.slice(0, -1))
            if (t > 0) {
                findingTimeLong = t * 1000 // seconds to milliseconds
            } else {
                handleError(`Invalid parameter duration: ${duration}`)
                return
            }
        } else if (durationType === 'findingTillTime') {
            try {
                const tillTime = new Date(duration)
                if (tillTime > new Date()) {
                    findingTillTime = tillTime
                } else {
                    handleError(`Invalid parameter duration: ${duration}`)
                    return
                }
            } catch (error) {
                handleError(`Invalid parameter duration: ${duration}, error: ${error}`)
                return
            }
        } else {
            handleError(`You have to provide a format valid duration!`)
            return
        }
    }

    const doFinding = () => {
        return new Promise((resolve, reject) => {
            const [result, error] = _at.findImage(options)
            // If got error, or got result, then the task is done
            if (error) {
                reject(error)
            } else {
                resolve(result)
            }
        })
    }

    const oneLoop = async () => {
        let result
        try {
            result = await doFinding()
        } catch (error) {
            handleError(error)
            return true // exit findImage()
        }
        if (eachFindingCallback) {
            eachFindingCallback()
        }
        if (result && result.length > 0) {
            const found = result && result.length > 0;
            if (found) {
                if (foundCallback) {
                    foundCallback(result)
                }
                if (exitIfFound) {
                    return true // exit findImage()
                }
            }
        }
        return false // do not exit findImage()
    }

    const doLoops = async () => {
        if (findingTimes) {
            let i = 1
            let firstLoop = true
            while (i < findingTimes) {
                if (!firstLoop) {
                    _usleep(interval_ * 1000)
                } else {
                    firstLoop = false
                }
                const exit = await oneLoop()
                if (exit) {
                    if (completedCallback) {
                        completedCallback()
                    }
                    return // exit findImage()
                }
                i++
            }
            if (completedCallback) {
                completedCallback()
            }
        } else if (findingTimeLong) {
            const startTime = new Date()
            let firstLoop = true
            while ((new Date() - startTime) < findingTimeLong) {
                if (!firstLoop) {
                    _usleep(interval_ * 1000)
                } else {
                    firstLoop = false
                }
                const exit = await oneLoop()
                if (exit) {
                    if (completedCallback) {
                        completedCallback()
                    }
                    return // exit findImage()
                }
            }
            if (completedCallback) {
                completedCallback()
            }
        } else if (findingTillTime) {
            let firstLoop = true
            while (new Date() < findingTillTime) {
                if (!firstLoop) {
                    _usleep(interval_ * 1000)
                } else {
                    firstLoop = false
                }
                const exit = await oneLoop()
                if (exit) {
                    if (completedCallback) {
                        completedCallback()
                    }
                    return // exit findImage()
                }
            }
            if (completedCallback) {
                completedCallback()
            }
        }
    }

    if (block) {
        return doLoops()
    } else {
        dispatch_async_global_queue(() => {
            return doLoops()
        })
    }
}

//---------------------------------------

at.copyText = function () {
    _at.copyText(...arguments)
}

at.clipText = function () {
    return _at.clipText()
}

//---------------------------------------

at.keepAutoTouchAwake = function (on) {
    _at.keepAutoTouchAwake(on)
}

at.openURL = function (urlString) {
    _at.openURL(urlString)
}

at.getLicense = function () {
    return _at.getLicense()
}

at.setTimer = function () {
    _at.setTimer(arguments)
}

at.removeTimer = function () {
    _at.removeTimer(...arguments)
}

at.setAutoLaunch = function () {
    _at.setAutoLaunch(...arguments)
}

at.listAutoLaunch = function () {
    return _at.listAutoLaunch()
}

at.stop = function () {
    return _at.stop();
}

at.playAudio = function () {
    _at.playAudio(...arguments)
}

at.pauseAudio = function () {
    _at.pauseAudio(...arguments)
}

at.resumeAudio = function () {
    _at.resumeAudio(...arguments)
}

at.stopAudio = function () {
    _at.stopAudio(...arguments)
}
//---------------------------------------

at.dialog = function () {
    return _at.dialog(...arguments)
}

at.clearDialogValues = function () {
    return _at.clearDialogValues(...arguments)
}

at.ocr = function () {
    const options = arguments[0]
    const callback = arguments[1]
    if (callback) {
        return _at.ocr(options, callback)
    } else {
        let result;
        let error;
        let returned = false;
        _at.ocr(options, (result_, error_) => {
            result = result_;
            error = error_;
            returned = true;
        })

        let timeout_ = options.timeout ?? 10
        timeout_ *= 10 // 10 seconds
        while (timeout_ > 0 && !returned) {
            _usleep(100000) // sleep 0.1 second
            timeout_--;
        }

        if (error) {
            return [null, error]
        }

        if (!returned && timeout_ <= 0) {
            return [null, 'timeout']
        }

        return [result, null]
    }
}

at.recognizeText = function () {
    console.log("Function `recognizeText()` is deprecated, please use `ocr()` instead, you will find it at https://docs.autotouch.net")
    return _at.ocr(...arguments)
}

at.recognizeTextSupportedLanguages = function () {
    return _at.recognizeTextSupportedLanguages()
}

// /**
//  * Keep finding text on the screen
//  * @param options: options for recognizeText
//  * @param tryings: how many times of tryings
//  * @param interval: milliseconds
//  * @param callback: handle the result
//  */
// at.findText = function (options, tryings, interval, callback) {
// 	tryings = tryings && tryings > -1 ? tryings : 1
// 	interval = interval && interval > 0 ? interval : 1000

// 	let i = 1;
// 	let loop = setInterval(() => {
// 		console.log('>>>>>> find text a time')
// 		_at.recognizeText(options, (result, error) => {
// 			// If got error, or got result, then the task is done
// 			if (error || result && result.lenght > 0) {
// 				clearInterval(loop)
// 				if (callback) {
// 					callback(result, error)
// 				}
// 			}
// 		})
// 		if (tryings > 0 && i == times) {
// 			clearInterval(loop)
// 		}
// 	}, interval);
// }
at.findText = function () {
    const isFirstArgumentRecognizationOptions = (typeof arguments[0] === 'object') || (typeof arguments[0] === null) || (typeof arguments[0] === undefined);
    const isOneTimeExecutionSync = arguments.length === 2 && isFirstArgumentRecognizationOptions && (typeof arguments[1] === 'function');
    const isOneTimeExecutionAsync = arguments.length === 3 && isFirstArgumentRecognizationOptions && (typeof arguments[1] === 'function') && (typeof arguments[2] === 'function');
    if (isOneTimeExecutionSync) {
        const options = arguments[0]
        const matchMethod = arguments[1]

        let result_, error_
        _at.ocr(options, (result, error) => {
            if (error) {
                error_ = error
                return
            }
            if (result && result.length > 0) {
                const matchedRegions = result.filter(r => matchMethod(r.text)).map(r => r.rectangle)
                const found = matchedRegions.length > 0;
                if (found) {
                    result_ = matchedRegions
                    return
                }
            }
            result_ = []
            return
        })
        while (!result_ && error_) {
            _usleep(100)
        }
        return [result_, error_]
    } else if (isOneTimeExecutionAsync) {
        const options = arguments[0]
        const matchMethod = arguments[1]
        const callback = arguments[2]
        _at.ocr(options, (result, error) => {
            if (error) {
                callback(null, error)
                return
            }
            if (result && result.length > 0) {
                const matchedRegions = result.filter(r => matchMethod(r.text)).map(r => r.rectangle)
                const found = matchedRegions.length > 0;
                if (found) {
                    callback(matchedRegions, null)
                    return
                }
            }
            callback([], null)
            return
        })
        return
    }

    const { options, matchMethod, duration, interval, eachFindingCallback, foundCallback, exitIfFound, errorCallback, completedCallback, block } = arguments[0]

    const handleError = errorMessage => {
        if (errorCallback) {
            errorCallback(errorMessage)
        } else {
            alert(`Got error while finding text and you didn't provide the errorCallback parameter! Error: ${errorMessage}`)
        }
    }

    if (exitIfFound === null || exitIfFound === undefined) {
        exitIfFound = true
    }

    if (block === null || block === undefined) {
        block = false
    }

    if (!matchMethod) {
        handleError(`You have to provide parameter matchMethod to specify how to check matching!`)
        return
    }

    const interval_ = interval && interval > 0 ? interval : 1000

    const isValidDate = function (date) {
        return (new Date(date) !== "Invalid Date") && !isNaN(new Date(date));
    }

    let findingTimes, findingTimeLong, findingTillTime
    if (!duration) {
        findingTimes = 10
    } else {
        let durationType
        if (typeof duration === 'number') {
            durationType = 'findingTimes'
        } else if (typeof duration === 'string') {
            if (duration.match(/\d[sS]{1}/g)) {
                durationType = 'findingTimeLong'
            } else if (isValidDate(duration)) {
                durationType = 'findingTillTime'
            } else {
                handleError(`Invalid parameter duration: ${duration}`)
                return
            }
        } else {
            handleError(`Invalid parameter duration: ${duration}`)
            return
        }

        if (durationType === 'findingTimes') {
            if (duration > 0) {
                findingTimes = duration
            } else {
                handleError(`Invalid parameter duration: ${duration}`)
                return
            }
        } else if (durationType === 'findingTimeLong') {
            let t = parseInt(duration.slice(0, -1))
            if (t > 0) {
                findingTimeLong = t * 1000 // seconds to milliseconds
            } else {
                handleError(`Invalid parameter duration: ${duration}`)
                return
            }
        } else if (durationType === 'findingTillTime') {
            try {
                const tillTime = new Date(duration)
                if (tillTime > new Date()) {
                    findingTillTime = tillTime
                } else {
                    handleError(`Invalid parameter duration: ${duration}`)
                    return
                }
            } catch (error) {
                handleError(`Invalid parameter duration: ${duration}, error: ${error}`)
                return
            }
        } else {
            handleError(`You have to provide a format valid duration!`)
            return
        }
    }

    const doFinding = () => {
        return new Promise((resolve, reject) => {
            _at.ocr(options, (result, error) => {
                // If got error, or got result, then the task is done
                if (error) {
                    reject(error)
                } else {
                    resolve(result)
                }
            })
        })
    }

    const oneLoop = async () => {
        let result
        try {
            result = await doFinding()
        } catch (error) {
            handleError(error)
            return true // exit findText()
        }
        if (eachFindingCallback) {
            eachFindingCallback()
        }
        if (result && result.length > 0) {
            const matchedRegions = result.filter(r => matchMethod(r.text)).map(r => r.rectangle)
            const found = matchedRegions.length > 0;
            if (found) {
                if (foundCallback) {
                    foundCallback(matchedRegions)
                }
                if (exitIfFound) {
                    return true // exit findText()
                }
            }
        }
        return false // do not exit findText()
    }

    const doLoops = async () => {
        if (findingTimes) {
            let i = 1
            let firstLoop = true
            while (i < findingTimes) {
                if (!firstLoop) {
                    _usleep(interval_ * 1000)
                } else {
                    firstLoop = false
                }
                const exit = await oneLoop()
                if (exit) {
                    if (completedCallback) {
                        completedCallback()
                    }
                    return // exit findText()
                }
                i++
            }
            if (completedCallback) {
                completedCallback()
            }
        } else if (findingTimeLong) {
            const startTime = new Date()
            let firstLoop = true
            while ((new Date() - startTime) < findingTimeLong) {
                if (!firstLoop) {
                    _usleep(interval_ * 1000)
                } else {
                    firstLoop = false
                }
                const exit = await oneLoop()
                if (exit) {
                    if (completedCallback) {
                        completedCallback()
                    }
                    return // exit findText()
                }
            }
            if (completedCallback) {
                completedCallback()
            }
        } else if (findingTillTime) {
            let firstLoop = true
            while (new Date() < findingTillTime) {
                if (!firstLoop) {
                    _usleep(interval_ * 1000)
                } else {
                    firstLoop = false
                }
                const exit = await oneLoop()
                if (exit) {
                    if (completedCallback) {
                        completedCallback()
                    }
                    return // exit findText()
                }
            }
            if (completedCallback) {
                completedCallback()
            }
        }
    }

    if (block) {
        return doLoops()
    } else {
        dispatch_async_global_queue(() => {
            return doLoops()
        })
    }
}

at.exec = function (command) {
    return _at.exec(command)
}

//---------------------------------------
const fs = {}

fs.exists = function () {
    return _fs.exists(...arguments)
}

fs.isReadable = function () {
    return _fs.isReadable(...arguments)
}

fs.isWritable = function () {
    return _fs.isWritable(...arguments)
}

fs.createDirectory = function () {
    return _fs.createDirectory(...arguments)
}

fs.writeFile = function () {
    return _fs.writeFile(...arguments)
}

fs.readFile = function () {
    return _fs.readFile(...arguments)
}

fs.remove = function () {
    return _fs.remove(...arguments)
}

fs.copy = function () {
    return _fs.copy(...arguments)
}

fs.move = function () {
    return _fs.move(...arguments)
}

fs.createSymbolicLink = function () {
    return _fs.createSymbolicLink(...arguments)
}

fs.createHardLink = function () {
    return _fs.createHardLink(...arguments)
}

fs.getAttributes = function () {
    return _fs.getAttributes(...arguments)
}

fs.setAttributes = function () {
    return _fs.setAttributes(...arguments)
}

const plist = {}

plist.read = function (plistFilePath) {
    const [jsonString, error] = _plist.plistFileToJsonString(plistFilePath)
    if (error) {
        return [null, error]
    }
    let jsonObject;
    try {
        jsonObject = JSON.parse(jsonString)
    } catch (error) {
        return [null, error]
    }
    return [jsonObject, error]
}

plist.write = function (jsonObject, plistFilePath, format) {
    const jsonString = JSON.stringify(jsonObject)
    return _plist.jsonStringToPlistFile(jsonString, plistFilePath, format)
}

plist.load = function (plistString) {
    const [jsonString, error] = _plist.plistStringToJsonString(plistString);
    if (error) {
        return [null, error]
    }
    let jsonObject;
    try {
        jsonObject = JSON.parse(jsonString)
    } catch (error) {
        return [null, error]
    }
    return [jsonObject, error];
}

plist.dump = function (jsonObject, format) {
    const jsonString = JSON.stringify(jsonObject);
    return _plist.jsonStringToPlistString(jsonString, format);
}

//---------------------------------------

function assert(condition, message) {
    if (!condition) {
        throw message || "Assertion failed";
    }
}