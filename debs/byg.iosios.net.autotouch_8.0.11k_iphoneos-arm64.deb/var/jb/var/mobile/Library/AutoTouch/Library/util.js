'use strict';

// NOTE: These type checking functions intentionally don't use `instanceof`
// because it is fragile and can be easily faked with `Object.create()`.
var isArray = exports.isArray = Array.isArray;

function isBoolean(arg) {
    return typeof arg === 'boolean';
}
exports.isBoolean = isBoolean;

function isNull(arg) {
    return arg === null;
}
exports.isNull = isNull;

function isNullOrUndefined(arg) {
    return arg == null;
}
exports.isNullOrUndefined = isNullOrUndefined;

function isNumber(arg) {
    return typeof arg === 'number';
}
exports.isNumber = isNumber;

function isString(arg) {
    return typeof arg === 'string';
}
exports.isString = isString;

function isSymbol(arg) {
    return typeof arg === 'symbol';
}
exports.isSymbol = isSymbol;

function isUndefined(arg) {
    return arg === void 0;
}
exports.isUndefined = isUndefined;

function isRegExp(re) {
    return isObject(re) && objectToString(re) === '[object RegExp]';
}
exports.isRegExp = isRegExp;

function isObject(arg) {
    return typeof arg === 'object' && arg !== null;
}
exports.isObject = isObject;

function isDate(d) {
    return isObject(d) && objectToString(d) === '[object Date]';
}
exports.isDate = isDate;

function isError(e) {
    return isObject(e) &&
        (objectToString(e) === '[object Error]' || e instanceof Error);
}
exports.isError = isError;

function isFunction(arg) {
    return typeof arg === 'function';
}
exports.isFunction = isFunction;

function isPrimitive(arg) {
    return arg === null ||
        typeof arg === 'boolean' ||
        typeof arg === 'number' ||
        typeof arg === 'string' ||
        typeof arg === 'symbol' ||  // ES6 symbol
        typeof arg === 'undefined';
}
exports.isPrimitive = isPrimitive;

function isBuffer(arg) {
    return arg instanceof Buffer;
}
exports.isBuffer = isBuffer;

function objectToString(o) {
    return Object.prototype.toString.call(o);
}

// function format(format) {
//     var args = Array.prototype.slice.call(arguments, 1);
//     return format.replace(/{(\d+)}/g, function (match, number) {
//         return typeof args[number] != 'undefined'
//             ? JSON.stringify(args[number])
//             : match
//             ;
//     });
// }

function format(f) {
    if (!isString(f)) {
        var objects = [];
        for (var i = 0; i < arguments.length; i++) {
            objects.push(JSON.stringify(arguments[i]));
        }
        return objects.join(' ');
    }

    var formatRegExp = /%[sdj%]/g;

    var i = 1;
    var args = arguments;
    var len = args.length;
    var str = String(f).replace(formatRegExp, function (x) {
        if (x === '%%') return '%';
        if (i >= len) return x;
        switch (x) {
            case '%s': return String(args[i++]);
            case '%d': return Number(args[i++]);
            case '%j':
                try {
                    return JSON.stringify(args[i++]);
                } catch (_) {
                    return '[Circular]';
                }
            default:
                return x;
        }
    });
    for (var x = args[i]; i < len; x = args[++i]) {
        if (isNull(x) || !isObject(x)) {
            str += ' ' + x;
        } else {
            str += ' ' + JSON.stringify(x);
        }
    }
    return str;
};
exports.format = format;

function intToRgb(number) {
    return {
        red: (number & 0xFF0000) >> 16,
        green: (number & 0x00FF00) >> 8,
        blue: blue = (number & 0x0000FF)
    }
}
exports.intToRgb = intToRgb

function rgbToInt(red, green, blue) {
    return (red << 16) + (green << 8) + (blue);
}
exports.rgbToInt = rgbToInt